export * from "./ProyectsPageComponent";
