import "./App.css";
import { RouterAplication } from "./router/RouterAplication";

function App() {
  return (
    <>
      <RouterAplication></RouterAplication>
    </>
  );
}

export default App;
