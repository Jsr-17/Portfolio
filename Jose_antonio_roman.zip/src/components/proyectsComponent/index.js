export * from "./ProyectsComponent.jsx";
