export * from "./FooterComponent.jsx";
